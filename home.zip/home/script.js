$(".new-image").hover(function(){
    $(this).attr("src", function(index, attr){
        return attr.replace(".webp", "-active.jpg");
    });
}, function(){
    $(this).attr("src", function(index, attr){
        return attr.replace("-active.jpg", ".webp");
    });
});

$("collection-image").hover(function() {
        $(this).animate({opacity: 1.0}, 500);
    }, function() {
        $(this).animate({opacity: 0.75}, 500);
    });
};
